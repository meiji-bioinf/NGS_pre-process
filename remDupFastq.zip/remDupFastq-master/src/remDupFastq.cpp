/*
 * remDupFastq.cpp
 *
 *  Created on: 2014/04/21
 *      Author: mkobayashi
 */

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <boost/algorithm/string.hpp>
#include <boost/regex.hpp>
#include <math.h>
#include <time.h>
#include <sys/types.h>
#include <dirent.h>
#include <tr1/unordered_map>

#define MAX_STRING 128

using namespace std;

std::string Replace( std::string String1, std::string String2, std::string String3 )
{
    std::string::size_type  Pos( String1.find( String2 ) );

    while( Pos != std::string::npos )
    {
        String1.replace( Pos, String2.length(), String3 );
        Pos = String1.find( String2, Pos + String3.length() );
    }

    return String1;
}

string time(){
	struct tm *date;
	time_t now;
	int year, month, day;
	int hour, minute, second;
	time(&now);
	date = localtime(&now);
	year = date->tm_year + 1900;
	month = date->tm_mon + 1;
	day = date->tm_mday;
	hour = date->tm_hour;
	minute = date->tm_min;
	second = date->tm_sec;

	stringstream year_str;
	year_str.precision(4);
	year_str << year;
	string year2 = year_str.str();

	stringstream month_str;
	month_str.precision(2);
	month_str << month;
	string month2 = month_str.str();

	stringstream day_str;
	day_str.precision(2);
	day_str << day;
	string day2 = day_str.str();

	stringstream hour_str;
	hour_str.precision(2);
	hour_str << hour;
	string hour2 = hour_str.str();

	stringstream minute_str;
	minute_str.precision(2);
	minute_str << minute;
	string minute2 = minute_str.str();

	stringstream second_str;
	second_str.precision(2);
	second_str << second;
	string second2 = second_str.str();

	string result = year2 + "/" + month2 + "/" + day2 + " " + hour2 + ":" + minute2 + ":" + second2;

	return result;
}

string use_popen(){
	int memKB;
	int memMB;
	int memGB;
	string result;
	FILE *fp;
	char command[MAX_STRING];
	char output[MAX_STRING];
	sprintf(command, "grep VmSize /proc/%d/status", getpid());
	if ((fp = popen(command, "r")) == NULL) {
		/*Failure*/
//		return;
	}
	while (fgets(output, MAX_STRING, fp) != NULL) {
		//具体的な数値を取得する場合は、sscanf等で読み出し
		sscanf(output,"VmSize: %d kB",&memKB);
		if(memKB > 1048576){
			memGB = memKB / 1048576;
			stringstream memGBstr;
			memGBstr << "VmSize: " << memGB << " GB";
			result = memGBstr.str();
		}else if(memKB > 1024){
			memMB = memKB / 1024;
			stringstream memMBstr;
			memMBstr << "VmSize: " << memMB << " MB";
			result = memMBstr.str();
		}else{
			stringstream memKBstr;
			memKBstr << "VmSize: " << memKB << " KB";
			result = memKBstr.str();
		}
	}
	if (pclose(fp) == -1) {
		/*Failure*/
	}
	return result;
}

double string2double(const string& str){
	double rt;
	stringstream ss;
	ss << str;
	ss >> rt;
	return rt;
}

string double2string(double d){
	string rt;
	stringstream ss;
	ss << d;
	ss >> rt;
	return rt;
}

// 文字の出現回数をカウント
int CountChar(string word, char c) {
	int c_count = 0;
	for(int i=0; word[i]!='\0'; i++){
		if(word[i] == c){
			c_count++;
		}
	}
	return c_count;
}

class fastq {
private:
	string name;
	string seq;
	string third;
	string qual;
public:
	void setName(string str);
	void setSeq(string str);
	void setThird(string str);
	void setQual(string str);
	void disp();
	int lenSeq();
	int lenQual();
	bool checkLenSeqAndQual();
	void dispEachBaseNum();
	double aveQual();
};

void fastq::setName(string str){
	name = str;
}
void fastq::setSeq(string str){
	seq = str;
}
void fastq::setThird(string str){
	third = str;
}
void fastq::setQual(string str){
	qual = str;
}
void fastq::disp(){
	cout << name << endl;
	cout << seq << endl;
	cout << third << endl;
	cout << qual << endl;
}
int fastq::lenSeq(){
	return seq.size();
}
int fastq::lenQual(){
	return qual.size();
}
bool fastq::checkLenSeqAndQual(){
	if(seq.size() == qual.size()){
		return true;
	}else{
		return false;
	}
}
void fastq::dispEachBaseNum(){
	map<char, int> base_num;
	for(int i = 0, n = seq.size(); i < n; i++){
		base_num[seq[i]]++;
	}
	for(map<char, int>::iterator base_num_it = base_num.begin(); base_num_it != base_num.end(); base_num_it++){
		cout << (*base_num_it).first << " " << (*base_num_it).second << endl;
	}
}
double fastq::aveQual(){
	double total_qv = 0;
	for(int i = 0, n = qual.size(); i < n; i++){
		total_qv += qual[i] - 33;
	}
	return total_qv / qual.size();
}

float aveQual(string qual){
	double total_qv = 0;
	for(int i = 0, n = qual.size(); i < n; i++){
		total_qv += qual[i] - 33;
	}
	return total_qv / qual.size();
}

int main(int argc, char *argv[]){

	setvbuf(stdout, (char *)NULL, _IONBF, 0); // 出力のバッファを無効化（進捗を上書きして出力するため）
	setlocale(LC_NUMERIC,"ja_JP.utf8"); // ロケールを設定（数字の3桁毎のカンマ区切りのため）

	char* in_file1 = NULL;
	char* in_file2 = NULL;
	char* out_file1 = NULL;
	char* out_file2 = NULL;

	string usage = "Usage: remDupFastq <input fastq1> <input fastq2> <output fastq1> <output fastq2>";

	if(strcmp(argv[1], "--help") == 0){
		cout << usage << endl;
		exit(0);
	}

	if(argv[1] != NULL){
		in_file1 = argv[1];
	}else{
		cerr << usage << endl;
		exit(0);
	}
	if(argv[2] != NULL){
		in_file2 = argv[2];
	}else{
		cerr << usage << endl;
		exit(0);
	}
	if(argv[3] != NULL){
		out_file1 = argv[3];
	}else{
		cerr << usage << endl;
		exit(0);
	}
	if(argv[4] != NULL){
		out_file2 = argv[4];
	}else{
		cerr << usage << endl;
		exit(0);
	}

	if(in_file1 == NULL){
		cerr << usage << endl;
		exit(0);
	}
	if(in_file2 == NULL){
		cerr << usage << endl;
		exit(0);
	}
	if(out_file1 == NULL){
		cerr << usage << endl;
		exit(0);
	}
	if(out_file2 == NULL){
		cerr << usage << endl;
		exit(0);
	}

	cout << in_file1 << endl;
	cout << in_file2 << endl;
	cout << out_file1 << endl;
	cout << out_file2 << endl;

	ifstream ifs1(in_file1);

	if(ifs1.fail()){
			cerr << "File " << in_file1 << " do not exist.\n";
			exit(0);
	}

	string line;
	int line_count = 0;
	int total_line_count = 0;

	tr1::unordered_map<string, string> in_file_name;
	tr1::unordered_map<string, string> in_file_seq;
	tr1::unordered_map<string, string> in_file_third;
	tr1::unordered_map<string, string> in_file_qual;

	string name;
	vector<string> vName;
	cout << "START: reading " << in_file1 << " " << use_popen() << " " << time() <<  endl;
	while(getline(ifs1, line)){ //1行ずつ読み込み
		line_count++;
		total_line_count++;
		if(total_line_count % 100000 == 0){
			printf (" <- %'d ",total_line_count);
			cout << use_popen() << " " << time();
			printf (" \r");
		}
		if(line_count == 1){
			boost::algorithm::split(vName,line,boost::is_any_of(" ")); //行をスペースでsplit
			name = vName[0];
			in_file_name[name] = line;
//			name = line;
		}else if(line_count == 2){
			in_file_seq[name] = line;
		}else if(line_count == 3){
			in_file_third[name] = line;
		}else if(line_count == 4){
			in_file_qual[name] = line;

			name = "";
			line_count = 0;
		}
	}
	ifs1.close();
	cout << endl;
	cout << "END: reading " << in_file1 << " " << use_popen() << " " << time() <<  endl;

	ifstream ifs2(in_file2);

	if(ifs2.fail()){
			cerr << "File " << in_file2 << " do not exist.\n";
			exit(0);
	}

	tr1::unordered_map<string, string> in_file2_name;
	tr1::unordered_map<string, string> in_file2_seq;
	tr1::unordered_map<string, string> in_file2_third;
	tr1::unordered_map<string, string> in_file2_qual;

	line_count = 0;
	total_line_count = 0;

	name = "";
	string name2;
	string seq;
	string third;
	string qual;
	cout << "START: reading " << in_file2 << " " << use_popen() << " " << time() <<  endl;
	while(getline(ifs2, line)){ //1行ずつ読み込み
		line_count++;
		total_line_count++;
		if(total_line_count % 100000 == 0){
			printf (" <- %'d ",total_line_count);
			cout << use_popen() << " " << time();
			printf (" \r");
		}
		if(line_count == 1){
			boost::algorithm::split(vName,line,boost::is_any_of(" ")); //行をスペースでsplit
			name = vName[0];
			name2 = line;
		}else if(line_count == 2){
			seq = line;
		}else if(line_count == 3){
			third = line;
		}else if(line_count == 4){
			qual = line;
			string seq2 = in_file_seq[name] + "|" + seq;
			if(in_file2_qual[seq2].size() > 0){
				string qual2 = in_file_qual[name] + "|" + qual;
				if( aveQual(qual2) > aveQual(in_file2_qual[seq2])){
					in_file2_name[seq2] = in_file_name[name] + "|" + name2;
					in_file2_seq[seq2] = in_file_seq[name] + "|" + seq;
					in_file2_third[seq2] = in_file_third[name] + "|" + third;
					in_file2_qual[seq2] = in_file_qual[name] + "|" + qual;
				}
			}else{
				in_file2_name[seq2] = in_file_name[name] + "|" + name2;
				in_file2_seq[seq2] = in_file_seq[name] + "|" + seq;
				in_file2_third[seq2] = in_file_third[name] + "|" + third;
				in_file2_qual[seq2] = in_file_qual[name] + "|" + qual;
			}
			name = "";
			name2 = "";
			seq = "";
			third = "";
			qual = "";
			line_count = 0;
		}
	}
	ifs2.close();
	cout << endl;
	cout << "END: reading " << in_file2 << " " << use_popen() << " " << time() <<  endl;

	ofstream ofs1(out_file1);
	ofstream ofs2(out_file2);

	cout << "START: output " << use_popen() << " " << time() <<  endl;

	tr1::unordered_map<string, string>::iterator it = in_file2_name.begin();
	while(it != in_file2_name.end()){
		vector<string> name_vec;
		vector<string> seq_vec;
		vector<string> third_vec;
		vector<string> qual_vec;
		boost::algorithm::split(name_vec,in_file2_name[(*it).first],boost::is_any_of("|"));
		boost::algorithm::split(seq_vec,in_file2_seq[(*it).first],boost::is_any_of("|"));
		boost::algorithm::split(third_vec,in_file2_third[(*it).first],boost::is_any_of("|"));
		boost::algorithm::split(qual_vec,in_file2_qual[(*it).first],boost::is_any_of("|"));
		ofs1 << name_vec[0] << endl << seq_vec[0] << endl << third_vec[0] << endl << qual_vec[0] << endl;
		ofs2 << name_vec[1] << endl << seq_vec[1] << endl << third_vec[1] << endl << qual_vec[1] << endl;
		it++;
	}

	ofs1.close();
	ofs2.close();

	cout << "END: output " << use_popen() << " " << time() <<  endl;

}



