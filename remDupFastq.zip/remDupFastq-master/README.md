remDupFastq
===============

remove duplicated paired reads

version
	0.1

Required

	Boost C++ Libraries
	http://www.boost.org/

	If boost libraries is not installed in your machine, you need to install boost libraries as below.

	$ yum install boost

Install

	Download src/remDupFastq-0.1.tar.gz.
	Decompress tarball and install as below.

	$ tar xzvf remDupFastq-0.1.tar.gz
	$ cd remDupFastq-0.1
	$ ./configure
	$ make
	$ sudo make install


Usage

	remDupFastq -h
	Usage: remDupFastq <input fastq1> <input fastq2> <output fastq1> <output fastq2>
