/*
 * qvFiltFastq.cpp
 *
 *  Created on: 2015/11/04
 *      Author: mkobayashi
 */

#include <iostream>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <map>
#include <sys/types.h>
#include <unistd.h>
#include <zlib.h>

#define MAX_STRING 128

using namespace std;

std::string Replace( std::string String1, std::string String2, std::string String3 )
{
    std::string::size_type  Pos( String1.find( String2 ) );

    while( Pos != std::string::npos )
    {
        String1.replace( Pos, String2.length(), String3 );
        Pos = String1.find( String2, Pos + String3.length() );
    }

    return String1;
}

string time(){
	struct tm *date;
	time_t now;
	int year, month, day;
	int hour, minute, second;
	time(&now);
	date = localtime(&now);
	year = date->tm_year + 1900;
	month = date->tm_mon + 1;
	day = date->tm_mday;
	hour = date->tm_hour;
	minute = date->tm_min;
	second = date->tm_sec;

	stringstream year_str;
	year_str.precision(4);
	year_str << year;
	string year2 = year_str.str();

	stringstream month_str;
	month_str.precision(2);
	month_str << month;
	string month2 = month_str.str();

	stringstream day_str;
	day_str.precision(2);
	day_str << day;
	string day2 = day_str.str();

	stringstream hour_str;
	hour_str.precision(2);
	hour_str << hour;
	string hour2 = hour_str.str();

	stringstream minute_str;
	minute_str.precision(2);
	minute_str << minute;
	string minute2 = minute_str.str();

	stringstream second_str;
	second_str.precision(2);
	second_str << second;
	string second2 = second_str.str();

	string result = year2 + "/" + month2 + "/" + day2 + " " + hour2 + ":" + minute2 + ":" + second2;

	return result;
}

string use_popen(){
	int memKB;
	int memMB;
	int memGB;
	string result;
	FILE *fp;
	char command[MAX_STRING];
	char output[MAX_STRING];
	sprintf(command, "grep VmSize /proc/%d/status", getpid());
	if ((fp = popen(command, "r")) == NULL) {
		/*Failure*/
//		return;
	}
	while (fgets(output, MAX_STRING, fp) != NULL) {
		//具体的な数値を取得する場合は、sscanf等で読み出し
		sscanf(output,"VmSize: %d kB",&memKB);
		if(memKB > 1048576){
			memGB = memKB / 1048576;
			stringstream memGBstr;
			memGBstr << "VmSize: " << memGB << " GB";
			result = memGBstr.str();
		}else if(memKB > 1024){
			memMB = memKB / 1024;
			stringstream memMBstr;
			memMBstr << "VmSize: " << memMB << " MB";
			result = memMBstr.str();
		}else{
			stringstream memKBstr;
			memKBstr << "VmSize: " << memKB << " KB";
			result = memKBstr.str();
		}
	}
	if (pclose(fp) == -1) {
		/*Failure*/
	}
	return result;
}

double string2double(const string& str){
	double rt;
	stringstream ss;
	ss << str;
	ss >> rt;
	return rt;
}

string double2string(double d){
	string rt;
	stringstream ss;
	ss << d;
	ss >> rt;
	return rt;
}

// 文字の出現回数をカウント
int CountChar(string word, char c) {
	int c_count = 0;
	for(int i=0; word[i]!='\0'; i++){
		if(word[i] == c){
			c_count++;
		}
	}
	return c_count;
}

float aveQual(string qual, int phred){
	double total_qv = 0;
	for(int i = 0, n = qual.size(); i < n; i++){
		total_qv += qual[i] - phred;
	}
	return total_qv / qual.size();
}

void qvFilt1File(char* in_file, char* out_file, int qv_cutoff, unsigned int min_length, float min_ave_qv, int low_qv_val, float max_low_qv_ratio, int phred, int remReadsWithN){
	cout << "Input file: " << in_file << endl;
	cout << "Output file: " << out_file << endl;
	cout << "Min of base quality for cutoff: " << qv_cutoff << endl;
	cout << "Min of length: " << min_length << endl;
	cout << "Min of average base quality: " << min_ave_qv << endl;
	cout << "Low base quality value: " << low_qv_val << endl;
	cout << "Max of low base quality region ratio: " << max_low_qv_ratio << endl;
	cout << "Phred+" << phred << endl;

	ifstream ifs(in_file);
	ofstream ofs(out_file);

	if(ifs.fail()){
			cerr << "File " << in_file << " do not exist.\n";
			exit(0);
	}

	string line;
	int line_count = 0;
	unsigned long total_line_count = 0;

	string name;
	string seq;
	string third;
	string qual;
	string out_buf;
	int outFlag = 0;

	cout << "START: reading " << in_file << " " << use_popen() << " " << time() <<  endl;
	while(getline(ifs, line)){ //1行ずつ読み込み
		line_count++;
		total_line_count++;
		if(total_line_count % 100000 == 0){
			printf (" <- %'10lu ",total_line_count);
			printf (" \r");
			ofs << out_buf;
			out_buf = "";
		}
		if(line_count == 1){
			name = line;
		}else if(line_count == 2){
			seq = line;
		}else if(line_count == 3){
			third = line;
		}else if(line_count == 4){
			qual = line;
			unsigned int qual_length = qual.size();
			for(unsigned int i = 0; i < qual_length; i++){
				int q = qual[0];
				if((q - phred) < qv_cutoff || seq[0] == 'N' || seq[0] == 'n'){
					seq.erase(0, 1);
					qual.erase(0, 1);
				}else{
					break;
				}
			}
			reverse(seq.begin(), seq.end());
			reverse(qual.begin(), qual.end());
			qual_length = qual.size();
			for(unsigned int i = 0; i < qual_length; i++){
				int q = qual[0];
				if((q - phred) < qv_cutoff || seq[0] == 'N' || seq[0] == 'n'){
					seq.erase(0, 1);
					qual.erase(0, 1);
				}else{
					break;
				}
			}
			reverse(seq.begin(), seq.end());
			reverse(qual.begin(), qual.end());
			if(aveQual(qual, phred) >= min_ave_qv && seq.length() >= min_length){
				if(remReadsWithN == 1){
					if(seq.find('N') == string::npos && seq.find('n') == string::npos){
						outFlag = 1;
					}else{
						outFlag = 0;
					}
				}else{
					outFlag = 1;
				}
			}else{
				outFlag = 0;
			}
			if(outFlag == 1){
				float low_qv_count = 0;
				qual_length = qual.size();
				for(unsigned int i = 0; i < qual_length; i++){
					int q = qual[i];
					if((q - phred) < low_qv_val){
						low_qv_count++;
					}
				}
				if((low_qv_count / qual_length) <= max_low_qv_ratio){
					outFlag = 1;
				}else{
					outFlag = 0;
				}
			}
			if(outFlag == 1){
				out_buf += name + "\n";
				out_buf += seq + "\n";
				out_buf += third + "\n";
				out_buf += qual + "\n";
			}
			name = "";
			seq = "";
			third = "";
			qual = "";
			line_count = 0;
			outFlag = 0;
		}
	}
	ofs << out_buf;
	ifs.close();
	ofs.close();
	cout << endl;
	cout << "END: reading " << in_file << " " << use_popen() << " " << time() <<  endl;
}

void qvFilt2Files(char* in_file, char* in_file2, char* out_file, char* out_file2, int qv_cutoff, unsigned int min_length, float min_ave_qv, int low_qv_val, float max_low_qv_ratio, int phred, int remReadsWithN){
	cout << "Input file1: " << in_file << endl;
	cout << "Input file2: " << in_file2 << endl;
	cout << "Output file1: " << out_file << endl;
	cout << "Output file2: " << out_file2 << endl;
	cout << "Min of base quality for cutoff: " << qv_cutoff << endl;
	cout << "Min of length: " << min_length << endl;
	cout << "Min of average base quality: " << min_ave_qv << endl;
	cout << "Low base quality value: " << low_qv_val << endl;
	cout << "Max of low base quality region ratio: " << max_low_qv_ratio << endl;
	cout << "Phred+" << phred << endl;

	ifstream ifs(in_file);
	ifstream ifs2(in_file2);
	ofstream ofs(out_file);
	ofstream ofs2(out_file2);

	if(ifs.fail()){
			cerr << "File " << in_file << " do not exist.\n";
			exit(0);
	}
	if(ifs2.fail()){
			cerr << "File " << in_file2 << " do not exist.\n";
			exit(0);
	}

	string line;
	string line2;
	int line_count = 0;
	unsigned long total_line_count = 0;

	string name;
	string name2;
	string seq;
	string seq2;
	string third;
	string third2;
	string qual;
	string qual2;
	string out_buf;
	string out_buf2;
	int outFlag = 0;

	cout << "START: reading " << in_file << " and " << in_file2 << " " << use_popen() << " " << time() <<  endl;
	while(getline(ifs, line) && getline(ifs2, line2)){ //1行ずつ読み込み
		line_count++;
		total_line_count++;
		if(total_line_count % 100000 == 0){
			printf (" <- %'10lu ",total_line_count);
			printf (" \r");
			ofs << out_buf;
			ofs2 << out_buf2;
			out_buf = "";
			out_buf2 = "";
		}
		if(line_count == 1){
			name = line;
			name2 = line2;
		}else if(line_count == 2){
			seq = line;
			seq2 = line2;
		}else if(line_count == 3){
			third = line;
			third2 = line2;
		}else if(line_count == 4){
			qual = line;
			qual2 = line2;
			unsigned int qual_length = qual.size();
			for(unsigned int i = 0; i < qual_length; i++){
				int q = qual[0];
				if((q - phred) < qv_cutoff || seq[0] == 'N' || seq[0] == 'n'){
					seq.erase(0, 1);
					qual.erase(0, 1);
				}else{
					break;
				}
			}
			unsigned int qual_length2 = qual2.size();
			for(unsigned int i = 0; i < qual_length2; i++){
				int q = qual2[0];
				if((q - phred) < qv_cutoff || seq2[0] == 'N' || seq2[0] == 'n'){
					seq2.erase(0, 1);
					qual2.erase(0, 1);
				}else{
					break;
				}
			}
			reverse(seq.begin(), seq.end());
			reverse(seq2.begin(), seq2.end());
			reverse(qual.begin(), qual.end());
			reverse(qual2.begin(), qual2.end());
			qual_length = qual.size();
			for(unsigned int i = 0; i < qual_length; i++){
				int q = qual[0];
				if((q - phred) < qv_cutoff || seq[0] == 'N' || seq[0] == 'n'){
					seq.erase(0, 1);
					qual.erase(0, 1);
				}else{
					break;
				}
			}
			qual_length2 = qual2.size();
			for(unsigned int i = 0; i < qual_length2; i++){
				int q = qual2[0];
				if((q - phred) < qv_cutoff || seq2[0] == 'N' || seq2[0] == 'n'){
					seq2.erase(0, 1);
					qual2.erase(0, 1);
				}else{
					break;
				}
			}
			reverse(seq.begin(), seq.end());
			reverse(seq2.begin(), seq2.end());
			reverse(qual.begin(), qual.end());
			reverse(qual2.begin(), qual2.end());
			if(
				aveQual(qual, phred) >= min_ave_qv &&
				seq.length() >= min_length &&
				aveQual(qual2, phred) >= min_ave_qv &&
				seq2.length() >= min_length
			){
				if(remReadsWithN == 1){
					if(
						seq.find('N') == string::npos &&
						seq.find('n') == string::npos &&
						seq2.find('N') == string::npos &&
						seq2.find('n') == string::npos
					){
						outFlag = 1;
					}else{
						outFlag = 0;
					}
				}else{
					outFlag = 1;
				}
			}else{
				outFlag = 0;
			}
			if(outFlag == 1){
				float low_qv_count = 0;
				qual_length = qual.size();
				for(unsigned int i = 0; i < qual_length; i++){
					int q = qual[i];
					if((q - phred) < low_qv_val){
						low_qv_count++;
					}
				}
				float low_qv_count2 = 0;
				qual_length2 = qual2.size();
				for(unsigned int i = 0; i < qual_length2; i++){
					int q = qual2[i];
					if((q - phred) < low_qv_val){
						low_qv_count2++;
					}
				}
				if(
					(low_qv_count / qual_length) <= max_low_qv_ratio &&
					(low_qv_count2 / qual_length2) <= max_low_qv_ratio
				){
					outFlag = 1;
				}else{
					outFlag = 0;
				}
			}
			if(outFlag == 1){
				out_buf += name + "\n";
				out_buf += seq + "\n";
				out_buf += third + "\n";
				out_buf += qual + "\n";
				out_buf2 += name2 + "\n";
				out_buf2 += seq2 + "\n";
				out_buf2 += third2 + "\n";
				out_buf2 += qual2 + "\n";
			}
			name = "";
			seq = "";
			third = "";
			qual = "";
			line_count = 0;
			name2 = "";
			seq2 = "";
			third2 = "";
			qual2 = "";
			outFlag = 0;
		}
	}
	ofs << out_buf;
	ofs2 << out_buf2;
	ifs.close();
	ifs2.close();
	ofs.close();
	ofs2.close();
	cout << endl;
	cout << "END: reading " << in_file << " and " << in_file2 << " " << use_popen() << " " << time() <<  endl;
}

void qvFilt1FileGz(char* in_file, char* out_file, int qv_cutoff, unsigned int min_length, float min_ave_qv, int low_qv_val, float max_low_qv_ratio, int phred, int remReadsWithN){
	cout << "Input file: " << in_file << endl;
	cout << "Output file: " << out_file << endl;
	cout << "Min of base quality for cutoff: " << qv_cutoff << endl;
	cout << "Min of length: " << min_length << endl;
	cout << "Min of average base quality: " << min_ave_qv << endl;
	cout << "Low base quality value: " << low_qv_val << endl;
	cout << "Max of low base quality region ratio: " << max_low_qv_ratio << endl;
	cout << "Phred+" << phred << endl;

	char buf[1000000] = {0};
	gzFile zp;
	zp = gzopen(in_file, "rb6f");
	if(zp == NULL){
		fprintf(stderr, "gzopen error\n");
		exit(1);
	}
	gzFile outzp;
	outzp = gzopen(out_file, "w9");
	if(outzp == NULL){
		fprintf(stderr, "gzopen error\n");
		exit(1);
	}

	string line;
	int line_count = 0;
	unsigned long total_line_count = 0;

	string name;
	string seq;
	string third;
	string qual;
	string out_buf;
	int outFlag = 0;

	cout << "START: reading " << in_file << " " << use_popen() << " " << time() <<  endl;
	while(gzgets(zp, buf, sizeof(buf)) != Z_NULL){ //1行ずつ読み込み
		buf[strlen(buf)-1] = '\0';
		line = buf;

		line_count++;
		total_line_count++;
		if(total_line_count % 100000 == 0){
			printf (" <- %'10lu ",total_line_count);
			printf (" \r");
			gzputs(outzp, out_buf.c_str());
			out_buf = "";
		}
		if(line_count == 1){
			name = line;
		}else if(line_count == 2){
			seq = line;
		}else if(line_count == 3){
			third = line;
		}else if(line_count == 4){
			qual = line;
			unsigned int qual_length = qual.size();
			for(unsigned int i = 0; i < qual_length; i++){
				int q = qual[0];
				if((q - phred) < qv_cutoff || seq[0] == 'N' || seq[0] == 'n'){
					seq.erase(0, 1);
					qual.erase(0, 1);
				}else{
					break;
				}
			}
			reverse(seq.begin(), seq.end());
			reverse(qual.begin(), qual.end());
			qual_length = qual.size();
			for(unsigned int i = 0; i < qual_length; i++){
				int q = qual[0];
				if((q - phred) < qv_cutoff || seq[0] == 'N' || seq[0] == 'n'){
					seq.erase(0, 1);
					qual.erase(0, 1);
				}else{
					break;
				}
			}
			reverse(seq.begin(), seq.end());
			reverse(qual.begin(), qual.end());
			if(aveQual(qual, phred) >= min_ave_qv && seq.length() >= min_length){
				if(remReadsWithN == 1){
					if(seq.find('N') == string::npos && seq.find('n') == string::npos){
						outFlag = 1;
					}else{
						outFlag = 0;
					}
				}else{
					outFlag = 1;
				}
			}else{
				outFlag = 0;
			}
			if(outFlag == 1){
				float low_qv_count = 0;
				qual_length = qual.size();
				for(unsigned int i = 0; i < qual_length; i++){
					int q = qual[i];
					if((q - phred) < low_qv_val){
						low_qv_count++;
					}
				}
				if((low_qv_count / qual_length) <= max_low_qv_ratio){
					outFlag = 1;
				}else{
					outFlag = 0;
				}
			}
			if(outFlag == 1){
				out_buf += name + "\n";
				out_buf += seq + "\n";
				out_buf += third + "\n";
				out_buf += qual + "\n";
			}
			name = "";
			seq = "";
			third = "";
			qual = "";
			line_count = 0;
			outFlag = 0;
		}
	}
	gzputs(outzp, out_buf.c_str());
	gzclose(zp);
	gzclose(outzp);
	cout << endl;
	cout << "END: reading " << in_file << " " << use_popen() << " " << time() <<  endl;
}

void qvFilt2FilesGz(char* in_file, char* in_file2, char* out_file, char* out_file2, int qv_cutoff, unsigned int min_length, float min_ave_qv, int low_qv_val, float max_low_qv_ratio, int phred, int remReadsWithN){
	cout << "Input file1: " << in_file << endl;
	cout << "Input file2: " << in_file2 << endl;
	cout << "Output file1: " << out_file << endl;
	cout << "Output file2: " << out_file2 << endl;
	cout << "Min of base quality for cutoff: " << qv_cutoff << endl;
	cout << "Min of length: " << min_length << endl;
	cout << "Min of average base quality: " << min_ave_qv << endl;
	cout << "Low base quality value: " << low_qv_val << endl;
	cout << "Max of low base quality region ratio: " << max_low_qv_ratio << endl;
	cout << "Phred+" << phred << endl;

	char buf1[1000000] = {0};
	gzFile zp1;
	zp1 = gzopen(in_file, "rb6f");
	if(zp1 == NULL){
		fprintf(stderr, "gzopen error\n");
		exit(1);
	}
	char buf2[1000000] = {0};
	gzFile zp2;
	zp2 = gzopen(in_file2, "rb6f");
	if(zp2 == NULL){
		fprintf(stderr, "gzopen error\n");
		exit(1);
	}

	gzFile outzp1;
	outzp1 = gzopen(out_file, "w9");
	if(outzp1 == NULL){
		fprintf(stderr, "gzopen error\n");
		exit(1);
	}
	gzFile outzp2;
	outzp2 = gzopen(out_file2, "w9");
	if(outzp2 == NULL){
		fprintf(stderr, "gzopen error\n");
		exit(1);
	}

	string line;
	string line2;
	int line_count = 0;
	unsigned long total_line_count = 0;

	string name;
	string name2;
	string seq;
	string seq2;
	string third;
	string third2;
	string qual;
	string qual2;
	string out_buf;
	string out_buf2;
	int outFlag = 0;

	cout << "START: reading " << in_file << " and " << in_file2 << " " << use_popen() << " " << time() <<  endl;
	while(gzgets(zp1, buf1, sizeof(buf1)) != Z_NULL && gzgets(zp2, buf2, sizeof(buf2)) != Z_NULL){ //1行ずつ読み込み
		buf1[strlen(buf1)-1] = '\0';
		buf2[strlen(buf2)-1] = '\0';
		line = buf1;
		line2 = buf2;

		line_count++;
		total_line_count++;
		if(total_line_count % 100000 == 0){
			printf (" <- %'10lu ",total_line_count);
			printf (" \r");
			gzputs(outzp1, out_buf.c_str());
			gzputs(outzp2, out_buf2.c_str());
			out_buf = "";
			out_buf2 = "";
		}
		if(line_count == 1){
			name = line;
			name2 = line2;
		}else if(line_count == 2){
			seq = line;
			seq2 = line2;
		}else if(line_count == 3){
			third = line;
			third2 = line2;
		}else if(line_count == 4){
			qual = line;
			qual2 = line2;
			unsigned int qual_length = qual.size();
			for(unsigned int i = 0; i < qual_length; i++){
				int q = qual[0];
				if((q - phred) < qv_cutoff || seq[0] == 'N' || seq[0] == 'n'){
					seq.erase(0, 1);
					qual.erase(0, 1);
				}else{
					break;
				}
			}
			unsigned int qual_length2 = qual2.size();
			for(unsigned int i = 0; i < qual_length2; i++){
				int q = qual2[0];
				if((q - phred) < qv_cutoff || seq2[0] == 'N' || seq2[0] == 'n'){
					seq2.erase(0, 1);
					qual2.erase(0, 1);
				}else{
					break;
				}
			}
			reverse(seq.begin(), seq.end());
			reverse(seq2.begin(), seq2.end());
			reverse(qual.begin(), qual.end());
			reverse(qual2.begin(), qual2.end());
			qual_length = qual.size();
			for(unsigned int i = 0; i < qual_length; i++){
				int q = qual[0];
				if((q - phred) < qv_cutoff || seq[0] == 'N' || seq[0] == 'n'){
					seq.erase(0, 1);
					qual.erase(0, 1);
				}else{
					break;
				}
			}
			qual_length2 = qual2.size();
			for(unsigned int i = 0; i < qual_length2; i++){
				int q = qual2[0];
				if((q - phred) < qv_cutoff || seq2[0] == 'N' || seq2[0] == 'n'){
					seq2.erase(0, 1);
					qual2.erase(0, 1);
				}else{
					break;
				}
			}
			reverse(seq.begin(), seq.end());
			reverse(seq2.begin(), seq2.end());
			reverse(qual.begin(), qual.end());
			reverse(qual2.begin(), qual2.end());
			if(
				aveQual(qual, phred) >= min_ave_qv &&
				seq.length() >= min_length &&
				aveQual(qual2, phred) >= min_ave_qv &&
				seq2.length() >= min_length
			){
				if(remReadsWithN == 1){
					if(
						seq.find('N') == string::npos &&
						seq.find('n') == string::npos &&
						seq2.find('N') == string::npos &&
						seq2.find('n') == string::npos
					){
						outFlag = 1;
					}else{
						outFlag = 0;
					}

				}else{
					outFlag = 1;
				}
			}else{
				outFlag = 0;
			}
			if(outFlag == 1){
				float low_qv_count = 0;
				qual_length = qual.size();
				for(unsigned int i = 0; i < qual_length; i++){
					int q = qual[i];
					if((q - phred) < low_qv_val){
						low_qv_count++;
					}
				}
				float low_qv_count2 = 0;
				qual_length2 = qual2.size();
				for(unsigned int i = 0; i < qual_length2; i++){
					int q = qual2[i];
					if((q - phred) < low_qv_val){
						low_qv_count2++;
					}
				}
				if(
					(low_qv_count / qual_length) <= max_low_qv_ratio &&
					(low_qv_count2 / qual_length2) <= max_low_qv_ratio
				){
					outFlag = 1;
				}else{
					outFlag = 0;
				}
			}
			if(outFlag == 1){
				out_buf += name + "\n";
				out_buf += seq + "\n";
				out_buf += third + "\n";
				out_buf += qual + "\n";
				out_buf2 += name2 + "\n";
				out_buf2 += seq2 + "\n";
				out_buf2 += third2 + "\n";
				out_buf2 += qual2 + "\n";
			}
			name = "";
			seq = "";
			third = "";
			qual = "";
			line_count = 0;
			name2 = "";
			seq2 = "";
			third2 = "";
			qual2 = "";
			outFlag = 0;
		}
	}
	gzputs(outzp1, out_buf.c_str());
	gzputs(outzp2, out_buf2.c_str());
	gzclose(zp1);
	gzclose(zp2);
	gzclose(outzp1);
	gzclose(outzp2);
	cout << endl;
	cout << "END: reading " << in_file << " and " << in_file2 << " " << use_popen() << " " << time() <<  endl;
}


int main(int argc, char *argv[]){

	setvbuf(stdout, (char *)NULL, _IONBF, 0); // 出力のバッファを無効化（進捗を上書きして出力するため）
	setlocale(LC_NUMERIC,"ja_JP.utf8"); // ロケールを設定（数字の3桁毎のカンマ区切りのため）

	char* in_file = NULL;
	char* in_file2 = NULL;
	char* out_file = NULL;
	char* out_file2 = NULL;
	int pair_in_flag = 0;
	int pair_out_flag = 0;
	int qv_cutoff = 10;
	unsigned int min_length = 20;
	float min_ave_qv = 17;
	int low_qv_val = 10;
	float max_low_qv_ratio = 0.1;
	int phred = 33;
	int remReadsWithN = 1;

	string usage = "Version 0.9 \n Usage: qvFiltFastq -i <input fastq(.gz)> (-i2 <input fastq(.gz)>) ";
	usage += "-o <output fastq(.gz)> (-o2 <output fastq(.gz)>) \n";
	usage += "( -q <Min of base quality for cutoff [10]> -m <Min of length [20]> \n";
	usage += "-a <Min of average base quality [17]> -l <Low base quality value [10]> \n";
	usage += "-r <Max of low base quality region ratio [0.1]> -p <Phred scale> [33] -n <allow reads including 'N'>)";

	if(argc < 2){
		cerr << usage << endl;
		exit(0);
	}
	int i;
	for(i = 1; i < argc; i++){
		if(strcmp(argv[i], "-q") == 0){
			i++;
			qv_cutoff = atoi(argv[i]);
		}else if(strcmp(argv[i], "-m") == 0){
			i++;
			min_length = atoi(argv[i]);
		}else if(strcmp(argv[i], "-a") == 0){
			i++;
			min_ave_qv = atoi(argv[i]);
		}else if(strcmp(argv[i], "-l") == 0){
			i++;
			low_qv_val = atoi(argv[i]);
		}else if(strcmp(argv[i], "-r") == 0){
			i++;
			max_low_qv_ratio = atof(argv[i]);
		}else if(strcmp(argv[i], "--help") == 0){
			cout << usage << endl;
			exit(0);
		}else if(strcmp(argv[i], "-h") == 0){
			cout << usage << endl;
			exit(0);
		}else if(strcmp(argv[i], "-i") == 0){
			i++;
			in_file = argv[i];
		}else if(strcmp(argv[i], "-i2") == 0){
			i++;
			in_file2 = argv[i];
			pair_in_flag = 1;
		}else if(strcmp(argv[i], "-o") == 0){
			i++;
			out_file = argv[i];
		}else if(strcmp(argv[i], "-o2") == 0){
			i++;
			out_file2 = argv[i];
			pair_out_flag = 1;
		}else if(strcmp(argv[i], "-p") == 0){
			i++;
			phred = atoi(argv[i]);
		}else if(strcmp(argv[i], "-n") == 0){
			remReadsWithN = 0;
		}
	}

	if(phred != 33 && phred != 64){
		cout << "Phred+" << phred << " is wrong value." << endl;
		exit(0);
	}

	char t[64];
	if(pair_in_flag == 1 && pair_out_flag == 1){
		if(strcmp(strncpy(t, in_file+strlen(in_file)-3, 3), ".gz") == 0){
			qvFilt2FilesGz(in_file, in_file2, out_file, out_file2, qv_cutoff, min_length, min_ave_qv, low_qv_val, max_low_qv_ratio, phred, remReadsWithN);
		}else{
			qvFilt2Files(in_file, in_file2, out_file, out_file2, qv_cutoff, min_length, min_ave_qv, low_qv_val, max_low_qv_ratio, phred, remReadsWithN);
		}
	}else{
		if(strcmp(strncpy(t, in_file+strlen(in_file)-3, 3), ".gz") == 0){
			qvFilt1FileGz(in_file, out_file, qv_cutoff, min_length, min_ave_qv, low_qv_val, max_low_qv_ratio, phred, remReadsWithN);
		}else{
			qvFilt1File(in_file, out_file, qv_cutoff, min_length, min_ave_qv, low_qv_val, max_low_qv_ratio, phred, remReadsWithN);
		}
	}

}



