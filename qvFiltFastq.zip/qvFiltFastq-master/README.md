qvFiltFastq
===============

Extruct high-quality reads for a fastq format file

version
	0.9

Install

	Download src/qvFiltFastq-0.9.tar.gz.
	Decompress tarball and install as below.

	$ tar xzvf qvFiltFastq-0.9.tar.gz
	$ cd qvFiltFastq-0.9
	$ ./configure
	$ make
	$ sudo make install


Usage

	If a library is pair end, input and output a reverse reads file with -i2 and -o2.

	qvFiltFastq -i <input fastq(.gz)> (-i2 <input fastq(.gz)>) \
					-o <output fastq(.gz)> (-o2 <output fastq(.gz)>)
					(
						-q <Min of base quality for cutoff [10]> \
						-m <Min of length [20]> \
						-a <Min of average base quality [17]> \
						-l <Low base quality value [10]> \
						-r <Max of low base quality region ratio [0.1]> \
						-p <Phred scale> [33] \
						-n <Allow reads including 'N'>
					)
